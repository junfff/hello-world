Test cases for vim-plug
=======================

### Prerequisite

- [Vader.vim](https://github.com/junegunn/vader.vim)

### Run

```
./run

./run !
```

### TODO

Test cases for the following features are currently missing:

- Output formatting
- Timeout or interrupt cleaning up git processes
- User prompt in PlugClean command
- Single-threaded installer
- Windows support

